<?php
return array(
    'appName' => 'TestUnits',
    'serverName' => 'php',
    'objName' => 'testObj',
    'withServant' => true,
    'tarsFiles' => array(
        './php.tars',
    ),
    'dstPath' => '../src/servant',
    'namespacePrefix' => 'php\servant',
);
