<?php
return [
    'appName' => 'TestUnits', // 对应部署服务的应用名称
    'serverName' => 'php', // 对应部署服务的服务名称
    'objName' => 'testObj', // 对应部署服务的obj
];
