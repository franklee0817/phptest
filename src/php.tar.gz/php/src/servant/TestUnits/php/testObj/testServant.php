<?php

namespace php\servant\TestUnits\php\testObj;

interface testServant {
	/**
	 * @param string $req 
	 * @return string
	 */
	public function ping($req);
}

