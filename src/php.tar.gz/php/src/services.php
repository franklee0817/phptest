<?php
return [
    'testObj' => [
        'home-api' => '\php\servant\TestUnits\php\testObj\testServant',
        'home-class' => '\php\impl\test',
        'protocolName' => 'tars',
        'serverType' => 'tcp',
    ],
];
